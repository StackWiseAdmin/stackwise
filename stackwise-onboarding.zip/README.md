# StackWise – AI Investing Assistant

This is the MVP onboarding flow for StackWise, an AI-powered investing assistant for Gen Z.

## Features
- Multi-step onboarding flow
- Beginner-friendly tooltips
- React.js based frontend
