import React from 'react';

const InfoTooltip = ({ message }) => (
  <div className="relative group inline-block ml-2">
    <span className="cursor-pointer text-blue-600 font-bold">ℹ️</span>
    <div className="absolute z-10 hidden group-hover:block w-64 p-2 text-sm text-white bg-gray-800 rounded shadow-lg">
      {message}
    </div>
  </div>
);

export default InfoTooltip;
