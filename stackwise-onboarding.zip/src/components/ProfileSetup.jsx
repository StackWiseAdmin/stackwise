import React, { useState } from 'react';
import InfoTooltip from './InfoTooltip';

const ProfileSetup = ({ onNext }) => {
  const [age, setAge] = useState('');
  const [risk, setRisk] = useState(3);
  const [goal, setGoal] = useState('');

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4">Set Up Your Investor Profile</h2>

      <label className="block mb-2">Age<InfoTooltip message="To suggest time horizons for your investments." /></label>
      <input type="number" className="input w-full mb-4" value={age} onChange={(e) => setAge(e.target.value)} />

      <label className="block mb-2">Risk Tolerance<InfoTooltip message="It tells us how comfortable you are with ups and downs in your investment." /></label>
      <input type="range" min="1" max="5" className="w-full mb-4" value={risk} onChange={(e) => setRisk(e.target.value)} />

      <label className="block mb-2">Investment Goal<InfoTooltip message="Examples: retirement, saving for school, buying a house." /></label>
      <input type="text" className="input w-full mb-4" value={goal} onChange={(e) => setGoal(e.target.value)} />

      <button onClick={onNext} className="btn w-full bg-blue-600 text-white py-2 rounded">Continue</button>
    </div>
  );
};

export default ProfileSetup;
